# The `tuos_tb3_tools` Package

A ROS package containing convenience tools for the University of Sheffield TurtleBot3 Waffles.

Tom Howard  
July 2022  
Developed for the 2022/23 Academic Year
